//
//  FastpayMerchantSDK.h
//  FastpayMerchantSDK
//
//  Created by Anamul Habib on 14/3/21.
//

#import <Foundation/Foundation.h>

//! Project version number for FastpayMerchantSDK.
FOUNDATION_EXPORT double FastpayMerchantSDKVersionNumber;

//! Project version string for FastpayMerchantSDK.
FOUNDATION_EXPORT const unsigned char FastpayMerchantSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FastpayMerchantSDK/PublicHeader.h>


